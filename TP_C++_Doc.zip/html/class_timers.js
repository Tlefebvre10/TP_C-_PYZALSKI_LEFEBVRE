var class_timers =
[
    [ "Timers", "class_timers.html#a1b2e9ee6cb27d1246f7e6a888cf06556", null ],
    [ "GetValue", "class_timers.html#accfaeb6aceefb9a8aa8a9ee60a63d577", null ],
    [ "raz", "class_timers.html#a66919c6ab97f525c65baf3945f2b8e75", null ]
];