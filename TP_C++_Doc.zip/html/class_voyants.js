var class_voyants =
[
    [ "Voyants", "class_voyants.html#a0cb55f2ca8440b32faebe589af3ae874", null ],
    [ "GetDispo", "class_voyants.html#af92d52f5b82d75e31d064e5f6cb81477", null ],
    [ "SetBlinkCharge", "class_voyants.html#ac5a51624e1b4dedeac37c4c67ed764a2", null ],
    [ "SetCharge", "class_voyants.html#a689e0415126988013afa1b5b3490e375", null ],
    [ "SetDispo", "class_voyants.html#a8a45aa34bc31b6b5611cffc3ab607a68", null ]
];