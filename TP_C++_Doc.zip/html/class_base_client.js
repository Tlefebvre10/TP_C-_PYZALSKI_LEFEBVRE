var class_base_client =
[
    [ "BaseClient", "class_base_client.html#afac923d76994d020493b283908c24b3d", null ],
    [ "ajouter", "class_base_client.html#a0445334c0d4b5c9d3bfd013e8e58b288", null ],
    [ "GetNom", "class_base_client.html#a963d910a392839f12f7746ae30dbf9c8", null ],
    [ "GetPrenom", "class_base_client.html#a5663e4e1cfaf590f18e8b1ed50687ef3", null ],
    [ "GetSU", "class_base_client.html#a6dd6b7d73e5aa81e7997e20d5a92d08b", null ],
    [ "identifier", "class_base_client.html#acda6b6e3d331ece35e513b31fcf2bbc4", null ],
    [ "retirer", "class_base_client.html#a6819d4b237dc2a5b38a9d4e57fe1e6a1", null ]
];