var namespaces_dup =
[
    [ "std", "namespacestd.html", null ]
];